const s="/assets/50309213222-CL-tu3Bh.png";export{s as _};
