const s="/assets/RC-CaRWLE-r.jpg";export{s as _};
