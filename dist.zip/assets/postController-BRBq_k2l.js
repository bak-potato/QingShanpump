import{a as s}from"./request-BKIWkwTL.js";const e=t=>s.post("/api/post/delete",t),a=t=>s.post("/api/post/list/page",t);export{e as d,a as l};
