import{B as t}from"./index-Blcj2GrI.js";const o=t("question",{state:()=>({selectedQuestionId:null}),actions:{setSelectedQuestionId(e){this.selectedQuestionId=e}}});export{o as u};
